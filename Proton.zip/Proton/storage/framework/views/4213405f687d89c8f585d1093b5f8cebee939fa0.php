<?php $__env->startSection('title','Staff'); ?>


 <?php $__env->startSection('container2'); ?>
  <div class="row">
    <div class="col-10" style="margin-top: 80px; margin-left: 20px; margin-bottom: 85px">
      <h3>Daftar Staff PROTON</h3>
      <table class="table">
          <tbody>
          <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($loop->iteration); ?></th>
              <td> <?php echo e($stf->id_staff); ?> </td>
              <td> <?php echo e($stf->nama_staff); ?> </td>
              <td> <?php echo e($stf->email); ?> </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
    </div>
  </div>
</div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proton\resources\views/staff.blade.php ENDPATH**/ ?>