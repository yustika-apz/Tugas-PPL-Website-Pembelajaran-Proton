<?php $__env->startSection('title','Website Pembelajaran Proton'); ?>



 <?php $__env->startSection('container2'); ?>

  <div class="row" style="margin-top: 20px">
  <div class="col-md-12 col-xs-12">
    <center>
<div class="jumbotron card card-image" style="background-image: url('img/jumbotron.jpg');  background-size: cover; background-repeat: no-repeat; background-position: center; ">
  <div class="text-white text-center py-5 px-4">
    <div>
      <h2 class="card-title h1-responsive pt-3 mb-5 font-bold"><strong>Selamat Datang Di Website PROTON</strong></h2>
    </div>
  </div>
</div>
</center>
</div>
</div>





  <div class="container-fluid">
  <div class="row" style="margin-top: 0px">
  <div class="col-md-12 col-xs-12">
    <center>
<div class="row">
<?php
  $i = array()
?>
<?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php
  $i[] = $vid->video
  ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div class="col-md-4" style="margin-top: 3px">

            <div class="embed-responsive embed-responsive-16by9 z-depth-1-half">
              <iframe class="embed-responsive-item" src="<?php echo($i[0]) ?>"
                allowfullscreen></iframe>
            </div>

          </div>




  <div class="col-md-4" style="margin-top: 3px">

            <div class="embed-responsive embed-responsive-16by9 z-depth-1-half">
              <iframe class="embed-responsive-item" src="<?php echo($i[1]) ?>"
                allowfullscreen></iframe>
            </div>

          </div>




  <div class="col-md-4" style="margin-top: 3px">

            <div class="embed-responsive embed-responsive-16by9 z-depth-1-half">
              <iframe class="embed-responsive-item" src="<?php echo($i[2]) ?>"
                allowfullscreen></iframe>
            </div>

          </div>


  </div>
    </center>
</div>
</div>
</div>


<div class="container-fluid">
  <div class="row" style="margin-top: 40px">
    <div class="col-md-12">

<!--Carousel Wrapper-->
<div id="carousel-example-1z" class="carousel slide carousel-fade" data-ride="carousel">
  <!--Indicators-->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-1z" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-1z" data-slide-to="1"></li>
    <li data-target="#carousel-example-1z" data-slide-to="2"></li>
  </ol>
  <!--/.Indicators-->
  <!--Slides-->
  <div class="carousel-inner" role="listbox">
  <?php
  $i = array()
?>
<?php $__currentLoopData = $gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php
  $i[] = $gam->gambar
  ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!--First slide-->
    <div class="carousel-item active">
      <img class="d-block w-100" src="<?php echo($i[0]) ?>" class="img-fluid" alt="Responsive image"
        alt="First slide">
    </div>
    <!--/First slide-->
    <!--Second slide-->
    <div class="carousel-item">
      <img class="d-block w-100" src="<?php echo($i[1]) ?>" class="img-fluid" alt="Responsive image"
        alt="Second slide">
    </div>
    <!--/Second slide-->
    <!--Third slide-->
    <div class="carousel-item">
      <img class="d-block w-100" src="<?php echo($i[2]) ?>" class="img-fluid" alt="Responsive image"
        alt="Third slide">
    </div>
    <!--/Third slide-->
  </div>
  <!--/.Slides-->
  <!--Controls-->
  <a class="carousel-control-prev" href="#carousel-example-1z" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carousel-example-1z" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
  <!--/.Controls-->
</div>
<!--/.Carousel Wrapper-->

</div>
</div>
</div>


 <div class="container-fluid">
  <div class="row" style="margin-top: 20px">
  <div class="col-md-12 col-xs-12">
    <center>
<div class="row">
<?php
  $i = array()
?>
<?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php
  $i[] = $fot->foto
  ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php
  $k = array()
?>
<?php $__currentLoopData = $isi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php
  $k[] = $isi->isi
  ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <div class="col-md-4">
<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="<?php echo($i[0]) ?>" class="img-fluid" alt="Responsive image" alt="Card image cap">
  <div class="card-body">
    <p class="card-text"><?php echo($k[0]) ?></p>
  </div>
</div>
</div>

<div class="col-md-4">
<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="<?php echo($i[1]) ?>" class="img-fluid" alt="Responsive image" alt="Card image cap">
  <div class="card-body">
    <p class="card-text"><?php echo($k[1]) ?></p>
  </div>
</div>
</div>

<div class="col-md-4">
<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="<?php echo($i[2]) ?>" class="img-fluid" alt="Responsive image" alt="Card image cap">
  <div class="card-body">
    <p class="card-text"><?php echo($k[2]) ?></p>
  </div>
</div>
</div>
</div>
</center>

  </div>
  </div>
</div>





 <?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proton\resources\views/main.blade.php ENDPATH**/ ?>