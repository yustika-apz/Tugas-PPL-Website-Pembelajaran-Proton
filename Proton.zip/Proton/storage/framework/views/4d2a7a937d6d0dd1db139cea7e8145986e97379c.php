<?php $__env->startSection('title','Materi'); ?>


 <?php $__env->startSection('container2'); ?>
 <div class="container-fluid" style="margin-top: 20px">
  <div class="row">
    <div class="col-md-12">
        <center>
      <div class="row" style="margin-top: 20px">
  <div class="col-md-12" >
    <div class="list-group" id="list-tab" role="tablist" style="width:50%">
      <a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="home">SD</a>
      <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#list-profile" role="tab" aria-controls="profile">SMP</a>
      <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="#list-messages" role="tab" aria-controls="messages">SMA IPA</a>
      <a class="list-group-item list-group-item-action" id="list-settings-list" data-toggle="list" href="#list-settings" role="tab" aria-controls="settings">SMA IPS</a>
    </div>
  </div>

  <div class="col-md-12">
    
    <div class="tab-content" id="nav-tabContent"  style="margin-top: 30px;  margin-bottom:30px;">
<?php
  $i = array()
?>
<?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php
  $i[] = $mat->link
  ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="tab-pane fade show active" id="list-home" role="tabpanel" aria-labelledby="list-home-list">
        
        <div class="media" >
        <div class="col-md-4">
        <img src="<?php echo e(('img/indonesia.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">Bahasa Indonesia</h5>
          Link Materi : <a href=" <?php echo($i[0]) ?>">Bahasa Indonesia</a></div>
          </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/inggris.png')); ?>" width="55" length="55" alt="...">
          <div class="media-body">
          <h5 class="mt-0">Bahasa Inggris</h5>
          Link Materi : <a href=" <?php echo($i[1]) ?>">Bahasa Inggris</a></div>
          </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/ipa.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">IPA</h5>
          Link Materi : <a href=" <?php echo($i[2]) ?>">IPA</a></div>
        </div> </div>

        <div class="media" style="margin-top:30px">
        <div class="col-md-4">
          <img src="<?php echo e(('img/sejarah.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-2">IPS</h5>
          Link Materi : <a href=" <?php echo($i[3]) ?>">IPS</a></div>
          </div>
          <div class="col-md-4">
        <img src="<?php echo e(('img/pkn.png')); ?>" width="55" length="55" alt="...">
          <div class="media-body">
          <h5 class="mt-0">PKN</h5>
          Link Materi : <a href=" <?php echo($i[4]) ?>">PKN</a></div>
        </div> </div>
        
        </div>
      
      <div class="tab-pane fade" id="list-profile" role="tabpanel" aria-labelledby="list-profile-list">
      <div class="media">
      <div class="col-md-4">
          <img src="<?php echo e(('img/indonesia.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">Bahasa Indonesia</h5>
          Link Materi : <a href=" <?php echo($i[5]) ?>">Bahasa Indonesia</a></div> </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/inggris.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">Bahasa Inggris</h5>
          Link Materi : <a href=" <?php echo($i[6]) ?>">Bahasa Inggris</a></div> </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/math.png')); ?>" width="55" length="55" alt="...">
          <div class="media-body">
          <h5 class="mt-0">Matematika</h5>
          Link Materi : <a href=" <?php echo($i[7]) ?>">Matematika</a></div> </div>
        </div>

        <div class="media" style="margin-top:30px">
        <div class="col-md-4">
          <img src="<?php echo e(('img/ipa.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">IPA</h5>
          Link Materi : <a href=" <?php echo($i[8]) ?>">IPA</a></div> </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/sejarah.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-2">IPS</h5>
          Link Materi : <a href=" <?php echo($i[9]) ?>">IPS</a></div> </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/pkn.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">PKN</h5>
          Link Materi : <a href=" <?php echo($i[10]) ?>">PKN</a></div> </div>
        </div>

        <div class="media" style="margin-top:30px">
        <div class="col-md-4">
          <img src="<?php echo e(('img/pai.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">PAI</h5>
          Link Materi : <a href=" <?php echo($i[11]) ?>">PAI</a></div> </div>
        </div>
      </div>
      <div class="tab-pane fade" id="list-messages" role="tabpanel" aria-labelledby="list-messages-list">
      <div class="media">
      <div class="col-md-4">
          <img src="<?php echo e(('img/pkn.png')); ?>" width="55" length="55" alt="...">
          <div class="media-body">
          <h5 class="mt-0">PKN</h5>
          Link Materi : <a href=" <?php echo($i[12]) ?>">PKN</a></div> </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/tps.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">TPS</h5>
          Link Materi : <a href=" <?php echo($i[13]) ?>">TPS</a></div> </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/math.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">Matematika</h5>
          Link Materi : <a href=" <?php echo($i[14]) ?>">Matematika</a></div> </div>
        </div>

        <div class="media" style="margin-top:30px">
        <div class="col-md-4">
          <img src="<?php echo e(('img/ipa.png')); ?>" width="55" length="55" alt="...">
          <div class="media-body">
          <h5 class="mt-0">Biologi</h5>
          Link Materi : <a href=" <?php echo($i[15]) ?>">Biologi</a></div> </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/fisika.png')); ?>" width="55" length="55" alt="...">
          <div class="media-body">
          <h5 class="mt-0">Fisika</h5>
          Link Materi : <a href=" <?php echo($i[16]) ?>">Fisika</a></div> </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/kimia.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">Kimia</h5>
          Link Materi : <a href=" <?php echo($i[17]) ?>">Kimia</a></div> </div>
        </div>
      
        <div class="media" style="margin-top:30px">
        <div class="col-md-4">
          <img src="<?php echo e(('img/pai.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">PAI</h5>
          Link Materi : <a href=" <?php echo($i[18]) ?>">PAI</a></div> </div>
        </div>
        </div>

      <div class="tab-pane fade" id="list-settings" role="tabpanel" aria-labelledby="list-settings-list">
      <div class="media">
      <div class="col-md-4">
          <img src="<?php echo e(('img/pkn.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">PKN</h5>
          Link Materi : <a href=" <?php echo($i[19]) ?>">PKN</a></div> </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/tps.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">TPS</h5>
          Link Materi : <a href=" <?php echo($i[20]) ?>">TPS</a></div> </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/math.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">Matematika</h5>
          Link Materi : <a href=" <?php echo($i[21]) ?>">Matematika</a></div> </div>
        </div>

        <div class="media" style="margin-top:30px">
        <div class="col-md-4">
          <img src="<?php echo e(('img/geografi.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-0">Geografi</h5>
          Link Materi : <a href=" <?php echo($i[22]) ?>">Geografi</a></div> </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/sejarah.png')); ?>" width="55" length="55"  alt="...">
          <div class="media-body">
          <h5 class="mt-2">Sejarah</h5>
          Link Materi : <a href=" <?php echo($i[23]) ?>">Sejarah</a></div> </div>
          <div class="col-md-4">
          <img src="<?php echo e(('img/ekonomi.png')); ?>" width="55" length="55" alt="...">
          <div class="media-body">
          <h5 class="mt-0">Ekonomi</h5>
          Link Materi : <a href=" <?php echo($i[24]) ?>">Ekonomi</a></div> </div>
        </div>

        <div class="media" style="margin-top:30px">
        <div class="col-md-4">
          <img src="<?php echo e(('img/pai.png')); ?>" width="55" length="55" alt="...">
          <div class="media-body">
          <h5 class="mt-0">PAI</h5>
          Link Materi : <a href=" <?php echo($i[25]) ?>">PAI</a></div> </div>
        </div>

      </div>
      <div class="tab-pane fade" id="list-messages2" role="tabpanel" aria-labelledby="list-messages2-list">...</div>
    </div>
    
  </div>

  <?php
  $j = array()
?>
<?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php
  $j[] = $jad->foto
  ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div class="container-fluid">
  <div class="row" style="margin-top: 20px">
    <div class="col-md-12"> 
  <center>  
    <img src="<?php echo($j[0]) ?>" class="img-fluid" alt="Responsive image">
  </center>
</div>
</div>
</div>


</div>
</center>
</div>
</div>
</div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proton\resources\views/materi.blade.php ENDPATH**/ ?>